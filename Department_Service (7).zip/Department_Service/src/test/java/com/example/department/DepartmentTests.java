package com.example.department;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.department.entity.Department;
import com.example.department.repository.DepartmentRepository;

@DataJpaTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@RunWith(SpringRunner.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class DepartmentTests {

    @Autowired
    private DepartmentRepository departmentRepository;

    // Junit test for saveEmployee
    @Test
    @Order(1)
    @Rollback(value = false)
    public void saveDepartmentTests() {
    	Department  department = new  Department ((long)1, "IT", "Banglore", "IT12");
        departmentRepository.save(department);
        Assertions.assertThat(department.getId()).isEqualTo(1L);
    }

    @Test
    @Order(2)
    public void getDepartmentTest() {
    	Department department = departmentRepository.findById(1L).get();

        Assertions.assertThat(department.getId()).isEqualTo(1L);
    }

    @Test
    @Order(3)
    @Rollback(value = false)
    public void getListOfCouponsTest() {
        List<Department> department = departmentRepository.findAll();
       
        Assertions.assertThat(department.size()).isGreaterThan(0);
    }
    
//    @Test
//    @Order(4)
//    @Rollback(value = false)
//    public void updateCouponTest() {
//        Coupon coupon = couponRepository.findById(1L).get();
//        coupon.setCouponDiscount("20");
//        Coupon couponUpdated = couponRepository.save(coupon);
//        Assertions.assertThat(couponUpdated.getCouponDiscount()).isEqualTo("20");
//    }
//    
    
    @Test
    @Order(4)
    @Rollback(value = false)
    public void deleteDepartmentTest(){

    	Department department = departmentRepository.findById(1L).get();
    	departmentRepository.delete(department);
    	Department department1 = null;
    	Department optionalDepartment = departmentRepository.findByDepartmentCode("IT12");
    	System.out.println(optionalDepartment);
        if(optionalDepartment != null){
        	department1 = optionalDepartment;
            Assertions.assertThat(department1).isNull();
        }
    }
}