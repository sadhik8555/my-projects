package com.example.department.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.department.entity.Department;
import com.example.department.exception.ResourceNotFoundException;
import com.example.department.repository.DepartmentRepository;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor

public class DepartmentServiceImpl implements DepartmentService {
   
	@Autowired
    private DepartmentRepository departmentRepository;
	
	
	 @Override
		public List<Department> getallDepartments() throws ResourceNotFoundException{
		 
	    	List<Department> departments1=departmentRepository.findAll();
	    	if(departments1 == null) {
	    		
	    		throw new ResourceNotFoundException("Data doesn't exist!!");
	    		
	    	}
			return departments1;
		}


    @Override
    public Department saveDepartment(Department department) throws ResourceNotFoundException  {
    	if(department == null) {
    		
    		throw new ResourceNotFoundException("Send the correct data!!");
    	}
        return departmentRepository.save(department);
    }

    @Override
    public Department getDepartmentById(Long departmentId) throws ResourceNotFoundException  {
        
    	Department department=departmentRepository.findById(departmentId).orElse(null);
        if(department == null) {
        	 
        	throw new ResourceNotFoundException("Data doesn't exists, check your id please!!"+departmentId);
        }
        return department;
     
    }


    @Override
	public void deleteDepartmentById(Long departmentId) throws ResourceNotFoundException  {
		
    	Department department =departmentRepository.findById(departmentId).orElse(null);
		if(department==null) {
			
			throw new ResourceNotFoundException("Customer doesn't exists!!"+departmentId);
		}
		departmentRepository.deleteById(departmentId);
		
	}


	
}