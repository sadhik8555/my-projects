package com.example.department.controller;




import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;


import com.example.department.entity.Department;

import com.example.department.repository.DepartmentRepository;
import com.example.department.service.DepartmentService;

import jakarta.validation.Valid;

import lombok.AllArgsConstructor;

@RestController

@AllArgsConstructor
public class DepartmentController {
    @Autowired
    private DepartmentService departmentService;
    
    @Autowired
    private DepartmentRepository departmentrepository;

    @PostMapping("/api/departments")
    public ResponseEntity<Department> saveDepartment( @Valid @RequestBody Department department) throws Throwable{
		Department savedDepartment = departmentService.saveDepartment(department);
        return new ResponseEntity<>(savedDepartment, HttpStatus.CREATED);	
    }

    @GetMapping("/api/departments/{id}")
    public ResponseEntity<Department> getDepartmentById(@PathVariable("id") Long  departmentId) throws Throwable{	
        Department department = departmentService.getDepartmentById(departmentId);
        return ResponseEntity.ok(department);
    }
    
    @GetMapping("/api/departments/get")
    public ResponseEntity<List<Department>> getAllDepartments() throws Throwable{
    	List<Department> department1 = departmentService.getallDepartments();
        return ResponseEntity.ok(  department1= departmentService.getallDepartments());
       
    }
    
    
    @DeleteMapping("/api/departments/{id}")
    public ResponseEntity<Void> deleteDepartmentbyId(@PathVariable("id") Long departmentId) throws Throwable{
        departmentService.deleteDepartmentById(departmentId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
    
    @PutMapping("/api/departments/{id}")
    public ResponseEntity<Department> updateDepartment(@PathVariable(value = "id") Long departmentId,@RequestBody Department department){
    	
    	 Department department1 = departmentrepository.findById(departmentId).get();
    		        
    		        department1.setDepartmentName(department.getDepartmentName());
    		        department1.setDepartmentAddress(department.getDepartmentAddress());
    		        department1.setDepartmentCode(department.getDepartmentCode());
    		       department1.setId(department.getId());
    		        return ResponseEntity.ok(department1);
    		}
} 