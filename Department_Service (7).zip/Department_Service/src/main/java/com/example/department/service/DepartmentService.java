package com.example.department.service;


import java.util.List;

import com.example.department.entity.Department;
import com.example.department.exception.ResourceNotFoundException;

public interface DepartmentService {
   
	Department saveDepartment(Department department) throws ResourceNotFoundException;
	
    Department getDepartmentById(Long departmentId) throws ResourceNotFoundException;
    
    List<Department> getallDepartments() throws ResourceNotFoundException;
    
	void deleteDepartmentById(Long departmentId) throws ResourceNotFoundException  ;
	
}