package io.reflectoring.Foodorders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodordersApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodordersApplication.class, args);
	}

}
