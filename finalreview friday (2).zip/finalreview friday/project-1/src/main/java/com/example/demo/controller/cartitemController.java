package com.example.demo.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.modal.cartitem;
import com.example.demo.repo.cartitemRepo;
import com.example.demo.service.cartitemService;


@CrossOrigin(origins ="*", allowedHeaders = "*")
@RestController
@RequestMapping("/crt")
public class cartitemController {
	
	@Autowired
	cartitemService cartitemservice;
	
	@Autowired
	cartitemRepo cartitemRepo;

	@GetMapping("/carts")
	private List<cartitem> getAllcartitem() {
		return cartitemservice.getAllcartitems();
	}
	
	@PostMapping("/cart_save")
	private cartitem savecartitem(@RequestBody cartitem cartitem1) {
		cartitemservice.saveOrUpdate(cartitem1);
		return cartitem1;
	}
	

	@GetMapping("/cartget/{cartitemid}")
	private cartitem getcartitem(@PathVariable("cartitemid") int cartitemid) {
		return cartitemservice.getcartitemById(cartitemid);
	}
	
	
	
	
	@DeleteMapping("/cartdelete/{cartitemid}")
	private void deleteProducts(@PathVariable("cartitemid") int cartitemid) {
		cartitemservice.delete(cartitemid);
	}
	
	@GetMapping("/getbyuser/{userid}")
	public List<cartitem> getByUser(@PathVariable int userid){
		return cartitemRepo.getCartItemByUserId(userid);
	}

	
}
