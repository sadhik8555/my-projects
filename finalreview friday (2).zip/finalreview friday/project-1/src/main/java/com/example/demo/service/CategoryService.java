package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.modal.Category;
import com.example.demo.repo.CategoryRepo;


@Service
@Transactional
public class CategoryService {

	
		final CategoryRepo categoryrepo;
	
		
		@Autowired
		public CategoryService(CategoryRepo categoryrepo) {
			this.categoryrepo = categoryrepo;

		}
		public List<Category> getAllCategory() {
			List<Category> categories = new ArrayList<Category>();
			categoryrepo.findAll().forEach(category1 -> {
				 categories.add(category1);
			});
			return categories;
		}
		public void saveOrUpdate(Category categories) {
			categoryrepo.save(categories);
		}
	
}
