             package com.example.demo.modal;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;


//import com.example.demo.modal.ProductsCategory;
import com.fasterxml.jackson.annotation.JsonIgnore;


import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;



@Entity
@Table(name="products")
public class Products {
	
	
	@Lob
	private String product_image;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int product_id;

	private String product_name;

	private int categoryId;
	
	@OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="categoryId", insertable=false, updatable= false)
	private Category categorydetails;

	private int product_price;
	
	private String product_descr;
	

	
	@ManyToMany
	@JsonIgnore
	@JoinTable(name = "carts_products", 
		joinColumns = @JoinColumn(name = "product_id"), 
	inverseJoinColumns = @JoinColumn(name = "cart_id"))
	private List<cartitem> addedCarts = new ArrayList<>();	
	


	
	



	public Products() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Products(String product_image, int product_id, String product_name, int category_Id,
			Category categorydetails, int product_price, String product_descr) {
		super();
		this.product_image = product_image;
		this.product_id = product_id;
		this.product_name = product_name;
		this.categoryId = category_Id;
		this.categorydetails = categorydetails;
		this.product_price = product_price;
		this.product_descr = product_descr;
	}

	
	
	
	
	

	public String getProduct_image() {
		return product_image;
	}

	public void setProduct_image(String product_image) {
		this.product_image = product_image;
	}

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	

	public int getProduct_price() {
		return product_price;
	}

	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}

	public String getProduct_descr() {
		return product_descr;
	}

	public void setProduct_descr(String product_descr) {
		this.product_descr = product_descr;
	}

	public Category getCategorydetails() {
		return categorydetails;
	}

	public void setCategorydetails(Category categorydetails) {
		this.categorydetails = categorydetails;
	}


	

}