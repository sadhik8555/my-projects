package com.example.demo.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="payment")
public class Payment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int payment_id;
	@Column(name = "cardname")
    private String cardname;
    @Column(name = "card_number")
    private Long card_number;
    @Column(name = "card_type")
    private String card_type;
    @Column(name = "exp_date")
    private String exp_date;
    @Column(name="cvv")
    private int cvv;
	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Payment(int payment_id, String cardname, Long card_number, String card_type, String exp_date, int cvv) {
		super();
		this.payment_id = payment_id;
		this.cardname = cardname;
		this.card_number = card_number;
		this.card_type = card_type;
		this.exp_date = exp_date;
		this.cvv = cvv;
	}
	public int getPayment_id() {
		return payment_id;
	}
	public void setPayment_id(int payment_id) {
		this.payment_id = payment_id;
	}
	public String getCardname() {
		return cardname;
	}
	public void setCardname(String cardname) {
		this.cardname = cardname;
	}
	public Long getCard_number() {
		return card_number;
	}
	public void setCard_number(Long card_number) {
		this.card_number = card_number;
	}
	public String getCard_type() {
		return card_type;
	}
	public void setCard_type(String card_type) {
		this.card_type = card_type;
	}
	public String getExp_date() {
		return exp_date;
	}
	public void setExp_date(String exp_date) {
		this.exp_date = exp_date;
	}
	public int getCvv() {
		return cvv;
	}
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	
	
	
    
}
