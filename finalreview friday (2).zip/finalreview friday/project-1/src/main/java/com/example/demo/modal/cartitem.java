package com.example.demo.modal;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;



import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class cartitem {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cartitemid;
	
	@Lob
	@Column(name ="productimage")
	private String productimage;
	
	private String productId;
	
	private int price;
	
	private String productName;
	
	private int quantity;
	
	@ManyToMany(mappedBy = "addedCarts")
	private List<Products> products = new ArrayList<>();
	
	private int userId;
	
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "userId", insertable = false, updatable = false)
	private User user;
	

	public cartitem() {
		super();
		// TODO Auto-generated constructor stub
	}

	public cartitem(int cartitemid, String productimage, String productId, int price, String productName) {
		super();
		this.cartitemid = cartitemid;
		this.productimage = productimage;
		this.productId = productId;
		this.price = price;
		this.productName = productName;
	}

	
	
	
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public List<Products> getProducts() {
		return products;
	}

	public void setProducts(List<Products> products) {
		this.products = products;
	}

	public int getCartitemid() {
		return cartitemid;
	}

	public void setCartitemid(int cartitemid) {
		this.cartitemid = cartitemid;
	}

	public String getProductimage() {
		return productimage;
	}

	public void setProductimage(String productimage) {
		this.productimage = productimage;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}


	
	
	
	
}
