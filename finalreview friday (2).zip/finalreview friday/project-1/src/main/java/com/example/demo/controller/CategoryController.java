package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.modal.Category;
import com.example.demo.modal.Event;
import com.example.demo.service.CategoryService;
import com.example.demo.service.EventService;

@CrossOrigin(origins ="*", allowedHeaders = "*")
@RestController
@RequestMapping("/cat")
public class CategoryController {
	

	
	@Autowired
	private CategoryService categoryservice;
	
	
	 @PostMapping("/catrepo")
	    public Category createCategory(@RequestBody Category categories) {
		 categoryservice.saveOrUpdate(categories);
		 return categories;
	    }
	 @GetMapping("/catList")
	    public List < Category > getAllCategory() {
	        return categoryservice.getAllCategory();
	    }

}
