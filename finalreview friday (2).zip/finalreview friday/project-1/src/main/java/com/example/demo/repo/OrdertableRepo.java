package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.modal.Ordertable;



public interface OrdertableRepo extends JpaRepository<Ordertable, Integer>{
	public List<Ordertable> getOrderByUserId(int userId);


	}


