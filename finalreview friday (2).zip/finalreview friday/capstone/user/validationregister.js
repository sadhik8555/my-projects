function registration()
{

    var name= document.getElementById("username").value;
    var email= document.getElementById("email").value;
    var pwd= document.getElementById("password").value;			
    // var cpwd= document.getElementById("retypepassword").value;
    
    //email id expression code
    var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/;
    var letters = /^[A-Za-z]+$/;
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if(name=='')
    {
        alert('Please enter your name');
    }
    // else if(!letters.test(name))
    // {
    //     alert('Name field required only alphabet characters');
    // }
    else if(email=='')
    {
        alert('Please enter your user email id');
    }
    else if (!filter.test(email))
    {
        alert('Invalid email');
    }
    else if(pwd=='')
    {
        alert('Please enter Password');
    }
    // else if(cpwd=='')
    // {
    //     alert('Enter Confirm Password');
    // }
    else if(!pwd_expression.test(pwd))
    {
        alert ('Upper case, Lower case, Special character and Numeric letter are required in Password filled');
    }
    // else if(pwd != cpwd)
    // {
    //     alert ('Password not Matched');
    // }
    else if(document.getElementById("password").value.length < 6)
    {
        alert ('Password minimum length is 6');
    }
    else if(document.getElementById("password").value.length > 12)
    {
        alert ('Password max length is 12');
    }
    else
    {				           
        console.log("1")                 
           alert('Thank You for Login & You are Redirecting to Lensmart Website');
          signup(); 
    }
}
function clearFunc()
{
    document.getElementById("username").value="";
    document.getElementById("email").value="";
    document.getElementById("password").value="";
}

var signUpForm = document.getElementById("signUpForm");
var Indicator = document.getElementById("Indicator");

function register() {
    signUpForm.style.transform = "translatex(0px)";
    Indicator.style.transform = "translatex(100px)";
}
const signup = async () => {
    let ourForm = document.getElementById("signUpForm");
    function handleForm(event) {
        event.preventDefault();
    }
    ourForm.addEventListener("submit", handleForm);
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "http://localhost:8086/api/userrepo");
    xhr.setRequestHeader("Content-type", "application/json");
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status == 200) {
                window.location.href = "./Login.html"
            }
        }
    };

    let data = JSON.stringify({
        username: document.forms["signUpForm"]["username"].value,
        email: document.forms["signUpForm"]["email"].value,
        password: document.forms["signUpForm"]["password"].value,

    });
    console.log(data);
    xhr.send(data);
};