# SeedStack distribution 
[![Build status](https://travis-ci.org/seedstack/distribution.svg?branch=master)](https://travis-ci.org/seedstack/distribution) [![Maven Central](https://maven-badges.herokuapp.com/maven-central/org.seedstack/distribution/badge.svg?style=flat)](https://maven-badges.herokuapp.com/maven-central/org.seedstack/distribution)

Open-Source reference distribution of the whole stack (dependency management, project archetypes, composite dependencies, ...).
More information [here](http://seedstack.org/getting-started/distribution/).

# Copyright and license

This source code is copyrighted by [The SeedStack Authors](https://github.com/seedstack/seedstack/blob/master/AUTHORS) and
released under the terms of the [Mozilla Public License 2.0](https://www.mozilla.org/MPL/2.0/). 
