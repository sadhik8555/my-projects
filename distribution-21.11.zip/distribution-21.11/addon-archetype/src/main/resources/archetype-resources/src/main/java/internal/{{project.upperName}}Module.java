package ${package}.internal;

import com.google.inject.AbstractModule;

public class {{project.upperName}}Module extends AbstractModule {
    @Override
    protected void configure() {
        // TODO: place Guice bindings here if any
    }
}
