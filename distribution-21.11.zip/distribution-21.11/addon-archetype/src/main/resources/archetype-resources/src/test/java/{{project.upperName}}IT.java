package ${package};

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.testing.junit4.internal.JUnit4Runner;

@RunWith(JUnit4Runner.class)
public class {{project.upperName}}IT {
    @Test
    public void testSomething() throws Exception {
        // TODO: write some integration test for add-on functionality
    }
}
