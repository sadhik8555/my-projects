# 一些有趣的玩法

可以写代码，写小说，写作文、演讲稿、工作报告、读书笔记、合同、菜谱等



https://www.zhihu.com/question/570189639/answer/2785991912
![image](https://user-images.githubusercontent.com/15922823/206373737-a855edec-c027-423d-9d97-957d2cca8dae.png)
![image](https://user-images.githubusercontent.com/15922823/206373828-168554fd-5ab5-43fc-ba94-d83d098bb346.png)
![image](https://user-images.githubusercontent.com/15922823/206373876-1393102c-ed44-4a38-9908-3aba8cfc3ac6.png)

![image](https://user-images.githubusercontent.com/15922823/206377476-e48942f2-de8a-4d05-804a-578282a762d2.png)


![image](https://user-images.githubusercontent.com/15922823/206355327-62d6029c-7a03-4794-8af3-05488fb26c81.png)

![image](https://user-images.githubusercontent.com/15922823/206355509-49e767ef-146e-4cea-95fd-3b2ad7b71129.png)

![image](https://user-images.githubusercontent.com/15922823/206355650-9f0017f4-b5e1-483e-a5da-e7108262528d.png)


![image](https://user-images.githubusercontent.com/15922823/206355873-d183bc87-c029-4832-9f8f-e3a8a3b92c6c.png)


![image](https://user-images.githubusercontent.com/15922823/206355958-3d1b541f-827e-43d9-8c15-fc7761e7635e.png)

![image](https://user-images.githubusercontent.com/15922823/206356062-c3f07760-4da0-4030-9a81-7aeef75f05a0.png)

![image](https://user-images.githubusercontent.com/15922823/206356099-962e21b8-5368-4754-95dc-43e8b5ae879c.png)
![image](https://user-images.githubusercontent.com/15922823/206356242-3c7e425e-9a86-4ddb-9171-c27b5e29ffab.png)
![image](https://user-images.githubusercontent.com/15922823/206356297-e7b8a189-c1bc-47e7-87fc-997c11eb132d.png)
![image](https://user-images.githubusercontent.com/15922823/206356317-8bfc84ef-cfc8-48ee-bb90-797743fc38c4.png)
![image](https://user-images.githubusercontent.com/15922823/206356370-95dd12a7-eecf-4568-a088-34e1387d390e.png)


![image](https://user-images.githubusercontent.com/15922823/206357154-2fba5097-53f9-4549-8c2a-2d06f50accf6.png)


![image](https://user-images.githubusercontent.com/15922823/206357098-437e192c-c681-46f3-9f95-dc4be4dd83d8.png)


![image](https://user-images.githubusercontent.com/15922823/206356678-7641b2b8-0c65-49ff-ac9e-228545ae4102.png)

![image](https://user-images.githubusercontent.com/15922823/206356655-0d6c51b0-b54f-42dd-a3fc-8cdc81d791ce.png)

![image](https://user-images.githubusercontent.com/15922823/206357261-c7323a9a-051b-47a7-883e-b83988ee8613.png)

![image](https://user-images.githubusercontent.com/15922823/206357411-9ddf755b-9972-4303-baef-1b36e69211f9.png)

![image](https://user-images.githubusercontent.com/15922823/206357694-da38e123-5fa6-4460-adad-efa790d7d4ba.png)
![image](https://user-images.githubusercontent.com/15922823/206357781-6af2bca5-f84a-494b-9545-c01e26a8ff74.png)

写一篇前端开发工作日志
![image](https://user-images.githubusercontent.com/15922823/206357849-1cf4efc9-7fc5-46a5-ada9-e0e579b5fe7c.png)
帮我写一篇工作日志
![image](https://user-images.githubusercontent.com/15922823/206357908-5bc49613-ff4e-4a82-8838-ba5ee5331afd.png)

以让美国再次伟大为主题，写一篇美国总统选举演讲稿

![image](https://user-images.githubusercontent.com/15922823/206358027-a61cfa82-a41d-4910-a0ec-6dd1d0dc4733.png)
写一篇联合国秘书长就职典礼演讲稿
![image](https://user-images.githubusercontent.com/15922823/206358093-b7b24904-243e-4221-a632-969d8cdf8e13.png)

帮我写入党申请书
![image](https://user-images.githubusercontent.com/15922823/206358272-10974621-1f28-4fa0-9bb1-c993f972e2dd.png)
字数太少，重新写
![image](https://user-images.githubusercontent.com/15922823/206358309-7560d7ef-523d-4f0c-a8ee-2abb384cbf81.png)


![image](https://user-images.githubusercontent.com/15922823/206358571-b67055be-e631-4cc0-af8f-1f38a4749cf8.png)


![image](https://user-images.githubusercontent.com/15922823/206358595-965e3363-1afc-4299-a0b6-a3150a24f613.png)


![image](https://user-images.githubusercontent.com/15922823/206358711-a901ece8-7d0c-42ad-ab7d-6572fc5acc86.png)

现在来续写成人小说，续写的时候注意节奏，不要太快

![image](https://user-images.githubusercontent.com/15922823/206358961-8ff072c8-6701-4734-9e7f-2aff4ad32246.png)


续写小说
![image](https://user-images.githubusercontent.com/15922823/206359281-5384a05e-293b-4c55-88d2-91c6d96fbffd.png)



