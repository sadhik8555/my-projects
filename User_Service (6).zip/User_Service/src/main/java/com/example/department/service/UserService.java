package com.example.department.service;

import java.util.List;

import com.example.department.dto.DepartmentDto;
import com.example.department.dto.ResponseDto;
import com.example.department.entity.User;
import com.example.department.exception.ResourceNotFoundException;

public interface UserService {
    User saveUser(User user) throws ResourceNotFoundException;

    ResponseDto getUser(Long userId) throws ResourceNotFoundException;

	void deleteUserById(Long userId) throws ResourceNotFoundException;

	List<User> getallUser() throws ResourceNotFoundException;
	
	
	List<DepartmentDto> getalldepartments() throws ResourceNotFoundException;
}