package com.example.department.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.department.dto.DepartmentDto;
import com.example.department.dto.ResponseDto;
import com.example.department.dto.Responselist;
import com.example.department.dto.UserDto;

import com.example.department.entity.User;
import com.example.department.exception.ResourceNotFoundException;
import com.example.department.repository.UserRepository;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {
  @Autowired
    private UserRepository userRepository;
  @Autowired
    private RestTemplate restTemplate;

   


    @Override
    public ResponseDto getUser(Long userId) {

        ResponseDto responseDto = new ResponseDto();
        User user = userRepository.findById(userId).get();
        UserDto userDto = mapToUser(user);

        ResponseEntity<DepartmentDto> responseEntity = restTemplate
                .getForEntity("http://localhost:8081/api/departments/"+user.getDepartmentId(),
                DepartmentDto.class);
     
        DepartmentDto departmentDto = responseEntity.getBody();

      

        responseDto.setUser(userDto);
        responseDto.setDepartment(departmentDto);

        return responseDto;
    }

    private UserDto mapToUser(User user){
        UserDto userDto = new UserDto();
        userDto.setId(user.getId());
        userDto.setFirstName(user.getFirstName());
        userDto.setLastName(user.getLastName());
        userDto.setEmail(user.getEmail());
        return userDto;
    }

	@Override
	public void deleteUserById(Long userId) throws ResourceNotFoundException  {
		User user =userRepository.findById(userId).orElse(null);
		if(user==null) {
			
			throw new ResourceNotFoundException("User doesn't exists!!"+userId);
		}
		userRepository.deleteById(userId);
		
	}
		
	

	@Override
	public List<User> getallUser() throws ResourceNotFoundException {

    	List<User> user1=userRepository.findAll();
    	if(user1==null) {
    		throw new ResourceNotFoundException("Data doesn't exist!!");
    		
    	}
		return user1;
	}

	@Override
	public User saveUser(User user) throws ResourceNotFoundException {
		
		
		
		
		if(user==null) {
			throw new ResourceNotFoundException("send the  correct data");
		}
		
		
		System.out.println(user.getEmail());
		
		User user1=userRepository.save(user);
		
		return user1;
	}

	@Override
	public List<DepartmentDto> getalldepartments() throws ResourceNotFoundException {
		
		
		 
		 System.out.println("111111111111111");
		 
		 Responselist response = restTemplate.
				 getForObject
				   ("http://localhost:8081/api/departments/get",Responselist.class);
		 System.out.println("22222222222");
		 List<DepartmentDto> departments = response.getDepartments();
		 System.out.println("33333333333");                  
		return departments;
	}                                                          

	
	
	
	
	
	
	
	
	
	
	
	
}