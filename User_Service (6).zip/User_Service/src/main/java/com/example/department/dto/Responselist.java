package com.example.department.dto;

import java.util.ArrayList;
import java.util.List;

public class Responselist {
	
	
	private List<DepartmentDto> departments;

	public List<DepartmentDto> getDepartments() {
		return departments;
	}

	public void setDepartments(List<DepartmentDto> departments) {
		this.departments = departments;
	}

	public Responselist(List<DepartmentDto> departments) {
		super();
		this.departments = departments;
	}

	

	public Responselist() {
		System.out.println("4444444444");
		departments = new ArrayList<>();
	}

   

}
