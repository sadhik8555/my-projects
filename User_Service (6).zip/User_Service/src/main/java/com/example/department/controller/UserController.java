package com.example.department.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.department.dto.DepartmentDto;
import com.example.department.dto.ResponseDto;

import com.example.department.entity.User;
import org.springframework.web.util.UriComponentsBuilder;

import com.example.department.repository.UserRepository;
import com.example.department.service.UserService;

import lombok.AllArgsConstructor;

@RestController

@AllArgsConstructor
public class UserController {

	@Autowired
    private UserService userService;
	
	  @Autowired
	    private UserRepository userRepository;


    @PostMapping("/api/users")
    public ResponseEntity<User> saveUser(@RequestBody User user) throws Throwable{
    	
        User savedUser = userService.saveUser(user);
        
        return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
    }

   
    
    @GetMapping("/api/users/{id}")
    public ResponseEntity<ResponseDto> getUser(@PathVariable("id") Long userId) throws Throwable{
        ResponseDto responseDto = userService.getUser(userId);
        return ResponseEntity.ok(responseDto);
    }
    
    
// @GetMapping("/api/users")
//    public ResponseEntity<List<User>> getAllUser() throws Throwable{
//    	ResponseEntity<List<User>> response= RestTemplate.exchange(SERVICE_ONE_URL,HttpMethod.GET,
//    			HttpEntity.EMPTY, new ParameterizedTypeReference<List<User>>() {
//				});
//        return ResponseEntity.status(  HttpStatus.SC_Ok).body(response.getBody());
//    }
//   
    
    @DeleteMapping("/api/users/{id}")
    public ResponseEntity<Void> deleteUserbyId(@PathVariable("id") Long userId) throws Throwable{
        userService.deleteUserById(userId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
    
    @PutMapping("/api/users/{id}")
    public ResponseEntity<User> updateDepartment(@PathVariable(value = "id") Long userId,@RequestBody User user){
    	
    	 User user1 = userRepository.findById(userId).get();
    		        
    		       user1.setFirstName(user.getFirstName());
    		       user1.setLastName(user.getLastName());
    		       user1.setEmail(user.getEmail());
    		       user1.setDepartmentId(user.getDepartmentId());
    		    
    		        return ResponseEntity.ok(user1);
    		}
    
    
    
    @GetMapping("/api/alldepartments")
    public List<DepartmentDto> getalldepartments() throws Throwable{
    	 List<DepartmentDto> responseDto = userService.getalldepartments();
        return responseDto;
    }
    
    
    
    
    
    
    
    
    
} 
