package com.example.department;

import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.department.entity.User;
import com.example.department.repository.UserRepository;

@DataJpaTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@RunWith(SpringRunner.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class UserTest {

    @Autowired
    private UserRepository userRepository;

    // Junit test for saveEmployee
    @Test
    @Order(1)
    @Rollback(value = false)
    public void saveUserTest() {
        User user = new User ((long) 1, "Sai","Ram","sairam@gmail.com","1" );
        userRepository.save(user);
        Assertions.assertThat(user.getId()).isGreaterThan(0);
    }

    @Test
    @Order(2)
    public void getCouponTest() {
        User coupon = userRepository.findById(1L).get();

        Assertions.assertThat(coupon.getId()).isEqualTo(1L);
    }

    @Test
    @Order(3)
    @Rollback(value = false)
    public void getListOfCouponsTest() {
        List<User> user = userRepository.findAll();

        Assertions.assertThat(user.size()).isGreaterThan(0);
    }
    
    @Test
    @Order(4)
    @Rollback(value = false)
    public void updateCouponTest() {
        User user = userRepository.findById(1L).get();
        user.setFirstName("sad");;
        User userUpdated = userRepository.save(user);
        Assertions.assertThat(userUpdated.getFirstName()).isEqualTo("sad");
    }
    
    
//    @Test
//    @Order(5)
//    @Rollback(value = false)
//    public void deleteCouponTest(){
//
//        User user = userRepository.findById(1L).get();
//        userRepository.delete(user);
//        User coupon1 = null;
//        List<User> optionalCoupon = userRepository.findById();
//        if(!optionalCoupon.isEmpty()){
//        	coupon1 = optionalCoupon;
//            Assertions.assertThat(coupon1).isNull();
//        }
    }
