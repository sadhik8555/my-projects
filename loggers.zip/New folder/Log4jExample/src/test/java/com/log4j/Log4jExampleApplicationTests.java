package com.log4j;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Log4jExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
