package com.log4j.Controller;




import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LogController {
	
	private static final Logger logger =LoggerFactory.getLogger(LogController.class);
	
	
	
	@GetMapping("/log")
	@ResponseBody
	public String logging() {
		
		logger.debug("loding index page..");
		
		return "logging";
	}

}
