package com.log4j.entity;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Booking")
public class LogginEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bookingid;
	
	private String passengername;
	
	private int passengerage;
	
	private String gender;

	public int getBookingid() {
		return bookingid;
	}

	public void setBookingid(int bookingid) {
		this.bookingid = bookingid;
	}

	public String getPassengername() {
		return passengername;
	}

	public void setPassengername(String passengername) {
		this.passengername = passengername;
	}

	public int getPassengerage() {
		return passengerage;
	}

	public void setPassengerage(int passengerage) {
		this.passengerage = passengerage;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public LogginEntity(int bookingid, String passengername, int passengerage, String gender) {
		super();
		this.bookingid = bookingid;
		this.passengername = passengername;
		this.passengerage = passengerage;
		this.gender = gender;
	}

	public LogginEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	

}
