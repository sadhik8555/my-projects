package com.example.demo.service;


import java.util.List;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.modal.Busbooking;



public interface BusBookingService {
   
	Busbooking savebooking(Busbooking details) throws ResourceNotFoundException;
    Busbooking getBookingDetailsById(int bokingId) throws ResourceNotFoundException;
    List<Busbooking> getallBookings() throws ResourceNotFoundException;
	void deleteBookingsById(int bookingid) throws ResourceNotFoundException  ;
	
}