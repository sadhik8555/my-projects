package com.example.demo.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.modal.Busbooking;
import com.example.demo.repo.BusRepository;

@Service

public class BusBookingServiceImpl implements BusBookingService {

	@Autowired
	private BusRepository busRepository;

	Logger log = LoggerFactory.getLogger(this.getClass());

	@Override
	public List<Busbooking> getallBookings() throws ResourceNotFoundException {
		log.debug("We have entered into getallBookings method");

		List<Busbooking> details1 = busRepository.findAll();
		if (details1 == null) {
			log.error("Unable to get the  Bus booking ");
			throw new ResourceNotFoundException("Data doesn't exist!!");

		}
		log.info("All bus booking details are got!..");
		return details1;
	}

	@Override
	public Busbooking savebooking(Busbooking details) throws ResourceNotFoundException {
		log.debug("We have entered into savebooking method");
		if (details == null) {
			log.error("Unable to save the  Bus booking : " + details);
			throw new ResourceNotFoundException("Send the correct data!!");
		}
		log.info(details + " Details are saved.");
		return busRepository.save(details);
	}

	@Override
	public Busbooking getBookingDetailsById(int bookingId) throws ResourceNotFoundException {
		log.debug("We have entered into getBookingDetailsById method");
		Busbooking details = busRepository.findById(bookingId).orElse(null);
		if (details == null) {
			log.error("Unable Get the  Bus booking details  with ID: " + bookingId);
			throw new ResourceNotFoundException("Customer doesn't exists!!" + bookingId);
		}
		log.info(bookingId + " Details are getted.");
		return details;

	}

	@Override
	public void deleteBookingsById(int bookingid) throws ResourceNotFoundException {

		log.debug("Entering delete booking method");
		Busbooking details = busRepository.findById(bookingid).orElse(null);
		if (details == null) {

			log.error("Unable to delete details with ID: " + bookingid);

			throw new ResourceNotFoundException("Customer doesn't exists!!" + bookingid);
		}
		busRepository.deleteById(bookingid);

		log.info("Specimen with ID " + bookingid + " was deleted.");

	}

}