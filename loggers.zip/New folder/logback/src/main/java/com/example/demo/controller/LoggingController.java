package com.example.demo.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.modal.Busbooking;
import com.example.demo.repo.BusRepository;
import com.example.demo.service.BusBookingServiceImpl;

import jakarta.validation.Valid;

@RestController
public class LoggingController {

	private static final Logger logger = LoggerFactory.getLogger(LoggingController.class);

	@Autowired
	private BusBookingServiceImpl busServiceImpl;
	@Autowired
	private BusRepository busRepository;
	Logger log = LoggerFactory.getLogger(this.getClass());

	@PostMapping("/api/Busbookings")
	public ResponseEntity<Busbooking> saveBusbooking(@Valid @RequestBody Busbooking busbooking) throws Throwable {
		
		System.out.println("111111111111111");
		log.debug("Entered into saving end  point");       
		System.out.println("111111111111111");

		Busbooking savedBusbooking = busServiceImpl.savebooking(busbooking);
		log.info("Details are saved ");
		System.out.println("111111111111111");

		return new ResponseEntity<>(savedBusbooking, HttpStatus.CREATED);
	}

	@GetMapping("/api/Busbookings/{id}")
	public ResponseEntity<Busbooking> getBusbookingById(@PathVariable("id") int BusbookingId) throws Throwable {
		log.debug("enterd into get BusBooking enf point");
		Busbooking Busbooking = busServiceImpl.getBookingDetailsById(BusbookingId);
		log.info("Details are got by id");
		return ResponseEntity.ok(Busbooking);
	}
	
	

	@GetMapping("/api/Busbookings/get")
	public ResponseEntity<List<Busbooking>> getAllBusbookings() throws Throwable {
		log.debug("Entered into getallBookings end point");
		List<Busbooking> Busbooking1 = busServiceImpl.getallBookings();
		log.info("All the bus bookings are got");
		return ResponseEntity.ok(Busbooking1 = busServiceImpl.getallBookings());

	}

	@DeleteMapping("/api/Busbookings/{id}")
	public ResponseEntity<Void> deleteBusbookingbyId(@PathVariable("id") int BusbookingId) throws Throwable {
		log.debug("Entered into delete bus booking end point");
		busServiceImpl.deleteBookingsById(BusbookingId);
		log.info("Bus booking detaills are delete by Id");
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	@PutMapping("/api/Busbookings/{id}")
	public ResponseEntity<Busbooking> updateBusbooking(@PathVariable(value = "id") int BusbookingId,
			@RequestBody Busbooking Busbooking) {
		log.debug("Entered into update booking end point");

		Busbooking Busbooking1 = busRepository.findById(BusbookingId).get();

		Busbooking1.setPassengername(Busbooking.getPassengername());
		Busbooking1.setPassengerage(Busbooking.getPassengerage());
		Busbooking1.setGender(Busbooking.getGender());
		Busbooking1.setBookingid(Busbooking.getBookingid());
		log.info("Details are updated!..");
		return ResponseEntity.ok(Busbooking1);
	}

}
