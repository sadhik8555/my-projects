package com.example.demo.modal;

import org.springframework.validation.annotation.Validated;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;



@Entity
@Table(name = "departments")
@Validated
public class Busbooking {
    
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int bookingid; 
	
	
	@NotNull(message="needn't be null")
	@Valid
	private String passengername;
	
	@NotNull(message="needn't be null")
	@Valid
	private int passengerage;
	
	@NotNull(message="needn't be null")
	@Valid
	private String gender;

	public int getBookingid() {
		return bookingid;
	}

	public void setBookingid(int bookingid) {
		this.bookingid = bookingid;
	}

	public String getPassengername() {
		return passengername;
	}

	public void setPassengername(String passengername) {
		this.passengername = passengername;
	}

	public int getPassengerage() {
		return passengerage;
	}

	public void setPassengerage(int passengerage) {
		this.passengerage = passengerage;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Busbooking(int bookingid, @NotNull(message = "needn't be null") @Valid String passengername,
			@NotNull(message = "needn't be null") @Valid int passengerage,
			@NotNull(message = "needn't be null") @Valid String gender) {
		super();
		this.bookingid = bookingid;
		this.passengername = passengername;
		this.passengerage = passengerage;
		this.gender = gender;
	}

	public Busbooking() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
    
   
}