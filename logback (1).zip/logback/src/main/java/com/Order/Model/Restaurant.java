package com.Order.Model;

import org.springframework.validation.annotation.Validated;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;



@Entity
@Table(name = "Orders")
@Validated
public class Restaurant {
    
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderid; 
	
	
	@NotNull(message="needn't be null")
	@Valid
	private String restaurantName;
	
	@NotNull(message="needn't be null")
	@Valid
	private String recipeName;
	
	@NotNull(message="needn't be null")
	@Valid
	private String rating;

	@NotNull(message="needn't be null")
	@Valid
	private String price;

	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public String getRestaurantName() {
		return restaurantName;
	}

	public void setRestaurantName(String restaurantName) {
		this.restaurantName = restaurantName;
	}

	public String getRecipeName() {
		return recipeName;
	}

	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public Restaurant(int orderid, @NotNull(message = "needn't be null") @Valid String restaurantName,
			@NotNull(message = "needn't be null") @Valid String recipeName,
			@NotNull(message = "needn't be null") @Valid String rating,
			@NotNull(message = "needn't be null") @Valid String price) {
		super();
		this.orderid = orderid;
		this.restaurantName = restaurantName;
		this.recipeName = recipeName;
		this.rating = rating;
		this.price = price;
	}

	public Restaurant() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
    
   
}