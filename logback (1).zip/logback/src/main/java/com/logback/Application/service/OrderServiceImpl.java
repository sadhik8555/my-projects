package com.logback.Application.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Order.Model.Restaurant;
import com.logback.Application.exception.ResourceNotFoundException;
import com.logback.Application.repo.OrderRepository;

import jakarta.validation.Valid;



@Service

public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepository orderRepository;

	Logger log = LoggerFactory.getLogger(this.getClass());

	@Override
	public List<Restaurant> getallOrders() throws ResourceNotFoundException {
		log.debug("We have entered into getallBookings method");

		List<Restaurant> details1 = orderRepository.findAll();
		if (details1 == null) {
			log.error("Unable to get the  Bus booking ");
			throw new ResourceNotFoundException("Data doesn't exist!!");

		}
		log.info("All bus booking details are got!..");
		return details1;
	}

	@Override
	public Restaurant saveorder(Restaurant details) throws ResourceNotFoundException {
		log.debug("We have entered into saveordering method");
		if (details == null) {
			log.error("Unable to save the  Recipe Ordering : " + details);
			throw new ResourceNotFoundException("Send the correct data!!");
		}
		log.info(details + " Details are saved.");
		return orderRepository.save(details);
	}

	@Override
	public Restaurant getOrderDetailsById(int orderId) throws ResourceNotFoundException {
		log.debug("We have entered into getOrderDetailsById method");
		Restaurant details = orderRepository.findById(orderId).orElse(null);
		if (details == null) {
			log.error("Unable Get the  Recipe Ordering details  with ID: " + orderId);
			throw new ResourceNotFoundException("Customer doesn't exists!!" + orderId);
		}
		log.info(orderId + " Details are getted.");
		return details;

	}

	@Override
	public void deleteOrdersById(int orderid) throws ResourceNotFoundException {

		log.debug("Entering delete order method");
		Restaurant details = orderRepository.findById(orderid).get();
		if (details == null) {

			log.error("Unable to delete details with ID: " + orderid);

			throw new ResourceNotFoundException("Customer doesn't exists!!" + orderid);
		}
		orderRepository.deleteById(orderid);

		log.info("Specimen with ID " + orderid + " was deleted.");

	}

	public Restaurant savebooking(@Valid Restaurant order) {
		// TODO Auto-generated method stub
		return null;
	}

}