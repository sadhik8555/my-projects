package com.logback.Application.controller;

import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Order.Model.Restaurant;
import com.logback.Application.repo.OrderRepository;
import com.logback.Application.service.OrderServiceImpl;

import jakarta.validation.Valid;

@RestController
public class LoggingController {

	private static final Logger logger = LoggerFactory.getLogger(LoggingController.class);

	@Autowired
	private OrderServiceImpl orderServiceImpl;
	@Autowired
	private OrderRepository orderRepository;
	Logger log = LoggerFactory.getLogger(this.getClass());

	@PostMapping("/api/Restaurant")
	public ResponseEntity<Restaurant> saveOrder(@Valid @RequestBody Restaurant order) throws Throwable {
		
		System.out.println("Order Confirmed");
		log.debug("Entered into saving end  point");       
		System.out.println("Order Confirmed");

		Restaurant savedOrder = orderServiceImpl.saveorder(order);
		log.info("Details are saved ");
		System.out.println("Order Confirmed");

		return new ResponseEntity<>(savedOrder, HttpStatus.CREATED);
	}

	@GetMapping("/api/Restaurant/{id}")
	public ResponseEntity<Restaurant> getOrderById(@PathVariable("id") int OrderId) throws Throwable {
		log.debug("enterd into get Order enf point");
		Restaurant Order = orderServiceImpl.getOrderDetailsById(OrderId);
		log.info("Details are got by id");
		return ResponseEntity.ok(Order);
	}
	
	

	@GetMapping("/api/Restaurant/get")
	public ResponseEntity<List<Restaurant>> getAllOrder() throws Throwable {
		log.debug("Entered into getallOrder end point");
		List<Restaurant> Order1 = orderServiceImpl.getallOrders();
		log.info("All the bus order are got");
		return ResponseEntity.ok(Order1 = orderServiceImpl.getallOrders());

	}

	@DeleteMapping("/api/Restaurant/{id}")
	public ResponseEntity<Void> deleteOrderbyId(@PathVariable("id") int OrderId) throws Throwable {
		log.debug("Entered into delete recipe order");
		orderServiceImpl.deleteOrdersById(OrderId);
		log.info("Recipe order detaills are delete by Id");
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	@PutMapping("/api/Orders/{id}")
	public ResponseEntity<Restaurant> updateOrder(@PathVariable(value = "id") int OrderId,
			@RequestBody Restaurant Order) {
		log.debug("Entered into update Ordering end point");

		Restaurant Busbooking1 = orderRepository.findById(OrderId).get();

		Busbooking1.setRestaurantName(Order.getRestaurantName());
		Busbooking1.setRecipeName(Order.getRestaurantName());
		Busbooking1.setRating(Order.getRating());
		Busbooking1.setPrice(Order.getPrice());
		log.info("Details are updated!..");
		return ResponseEntity.ok(Order);
	}

}
