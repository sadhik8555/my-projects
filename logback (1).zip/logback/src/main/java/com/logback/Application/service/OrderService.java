package com.logback.Application.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.Order.Model.Restaurant;
import com.logback.Application.exception.ResourceNotFoundException;


@Service
public interface OrderService {
   
	Restaurant saveorder(Restaurant details) throws ResourceNotFoundException;
	Restaurant getOrderDetailsById(int orderId) throws ResourceNotFoundException;
    List<Restaurant> getallOrders() throws ResourceNotFoundException;
	void deleteOrdersById(int orderid) throws ResourceNotFoundException  ;
	
}