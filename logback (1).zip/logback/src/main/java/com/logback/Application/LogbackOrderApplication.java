package com.logback.Application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogbackOrderApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogbackOrderApplication.class, args);
	}

}
