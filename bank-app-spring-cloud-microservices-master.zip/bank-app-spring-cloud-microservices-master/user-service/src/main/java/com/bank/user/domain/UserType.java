package com.bank.user.domain;

public enum UserType {

	CUSTOMER,
	EMPLOYEE;
}
