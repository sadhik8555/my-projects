package com.bank.user.domain;

public enum DepartmentType {

	ACCOUNTS,
	GRIEVANCE,
	INSURANCE,
	LOAN,
	SECURITY;
	
}
