package com.bank.user.domain;

public enum AccountType {

	SAVINGS,
	CURRENT;
}
