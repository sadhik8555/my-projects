package com.bank.user.domain;

public enum TransactionStatus {

	STARTED,
	ACTIVE,
	FAILED,
	COMPLETED
}
