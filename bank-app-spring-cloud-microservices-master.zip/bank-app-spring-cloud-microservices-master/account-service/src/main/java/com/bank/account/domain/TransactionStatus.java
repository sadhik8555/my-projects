package com.bank.account.domain;

public enum TransactionStatus {

	STARTED,
	ACTIVE,
	FAILED,
	COMPLETED
}
