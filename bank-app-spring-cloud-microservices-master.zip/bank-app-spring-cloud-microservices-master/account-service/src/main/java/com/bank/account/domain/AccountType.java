package com.bank.account.domain;

public enum AccountType {

	SAVINGS,
	CURRENT;
}
