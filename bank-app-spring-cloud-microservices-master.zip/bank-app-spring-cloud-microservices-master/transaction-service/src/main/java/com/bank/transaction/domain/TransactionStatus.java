package com.bank.transaction.domain;

public enum TransactionStatus {

	STARTED,
	ACTIVE,
	FAILED,
	COMPLETED
}
