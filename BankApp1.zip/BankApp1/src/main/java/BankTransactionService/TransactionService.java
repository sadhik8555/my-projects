package BankTransactionService;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import BankTransactionModel.AccountTransaction;
import BankTransactionRepository.TransactionRepository;
@Component
@Service
public class TransactionService 
{
	@Autowired
	TransactionRepository transRepo;
	
	public List<AccountTransaction> getAllTransaction()
	{
		List<AccountTransaction> transaction=transRepo.findAll();
		return transaction;
	}
	public AccountTransaction getTransactionById(int Id)
	{
		List<AccountTransaction> transaction=transRepo.findAll();
		AccountTransaction transdetails=null;
		for(AccountTransaction trans:transaction)
		{
			if(trans.getId()==Id)
				transdetails=trans;
		}
		return transdetails;
	}
	public AccountTransaction addTransaction(AccountTransaction transdetails)
	{
		transdetails.setId(getMaxId());
		transRepo.save(transdetails);
		return transdetails;
	}
	public int getMaxId() //utility method to get max id
	{
		return transRepo.findAll().size()+1;
	}
	
	public AccountTransaction updateTransaction(AccountTransaction transdetails)
	{
		transRepo.save(transdetails);
		return transdetails;
	}
	
	public void deleteTransaction(AccountTransaction transdetails)
	{
		
		transRepo.delete(transdetails);
	}
}
