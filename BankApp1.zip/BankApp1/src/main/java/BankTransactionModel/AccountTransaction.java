package BankTransactionModel;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="transaction_details")
public class AccountTransaction
{
	@Id
	@Column(name="id")
	private int id;
	
	@Column(name="type")
	private String type;
	
	@Column(name="amount")
	private double amount;
	
	@Column(name="acc_Id")
	private int acc_Id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public int getAcc_Id() {
		return acc_Id;
	}

	public void setAcc_Id(int acc_Id) {
		this.acc_Id = acc_Id;
	}

	public AccountTransaction(int id, String type, double amount, int acc_Id) {
		super();
		this.id = id;
		this.type = type;
		this.amount = amount;
		this.acc_Id = acc_Id;
	}

	public AccountTransaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	
}
