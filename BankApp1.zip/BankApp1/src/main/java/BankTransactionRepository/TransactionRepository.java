package BankTransactionRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import BankTransactionModel.AccountTransaction;

public interface TransactionRepository extends JpaRepository<AccountTransaction, Integer>
{

}
