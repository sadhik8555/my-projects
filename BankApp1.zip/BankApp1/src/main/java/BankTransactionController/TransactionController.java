package BankTransactionController;
import java.util.List;
import java.util.NoSuchElementException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import BankTransactionModel.AccountTransaction;
import BankTransactionService.TransactionService;
@RestController
@RequestMapping
public class TransactionController
{
	   @Autowired
	   TransactionService transService;
	   @GetMapping("/gettransaction")
	   public ResponseEntity<List<AccountTransaction>> getTransaction()
	   {
		   try 
		   {
			   List<AccountTransaction> transaction=transService.getAllTransaction();
			   return new ResponseEntity<List<AccountTransaction>>(transaction,HttpStatus.FOUND);
		   }
		   catch(Exception e)
		   {
			   return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		   }
	   }
	
		   @GetMapping("/gettransaction/{Id}")
		   public ResponseEntity<AccountTransaction> getTransactionById(@PathVariable(value="Id")int Id)
		   {
			   try
			   {
				   AccountTransaction transdetails=transService.getTransactionById(Id);
			      return new ResponseEntity<AccountTransaction>(transdetails,HttpStatus.FOUND);
			   }
			   catch(Exception e)
			   {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);   
			   }
		   }
		   @PostMapping("/addtransaction")
		   public ResponseEntity<AccountTransaction> addTransaction(@RequestBody AccountTransaction transdetails)
		   {
			   try
			   {
				  transdetails=transService.addTransaction(transdetails);
				  return new ResponseEntity<AccountTransaction>(transdetails,HttpStatus.CREATED);
			   }
			   catch(Exception e)
			   {
				  return new ResponseEntity<>(HttpStatus.CONFLICT);
			   }
			  
		   }
		   
		   @PutMapping("/updatetransaction")
		   public ResponseEntity<AccountTransaction> updateTransaction(@PathVariable(value="Id")int Id,@RequestBody AccountTransaction  transdetails)
		   {
			   try
			   {
				   AccountTransaction existing=transService.getTransactionById(Id);
			   
			   existing.setId(transdetails.getId());
			   existing.setType(transdetails.getType());
			   existing.setAmount(transdetails.getAmount());
			   transService.updateTransaction(existing);
			   
			   AccountTransaction updated=transService.updateTransaction(existing);
			   return new ResponseEntity<AccountTransaction>(updated,HttpStatus.OK);
			   
			   }
			   catch(Exception e)
			   {
				   return new ResponseEntity<>(HttpStatus.CONFLICT);
			   }
			   
		   }
		   
		   @DeleteMapping(path="/deletetransaction/{Id}")
		   public ResponseEntity<AccountTransaction> deleteTransaction(@PathVariable(value="Id")int Id)
		   {
			   AccountTransaction transdetails=null;
			try
			{
				transdetails=transService.getTransactionById(Id);
				transService.deleteTransaction(transdetails);
			}
			catch(NoSuchElementException e)
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<AccountTransaction>(transdetails,HttpStatus.OK);
		   
		}
}
