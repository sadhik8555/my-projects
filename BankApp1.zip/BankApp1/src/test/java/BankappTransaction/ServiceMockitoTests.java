package BankappTransaction;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import BankTransactionModel.AccountTransaction;
import BankTransactionRepository.TransactionRepository;
import BankTransactionService.TransactionService;
@TestMethodOrder(OrderAnnotation.class)
@SpringBootTest(classes= {ServiceMockitoTests.class})
public class ServiceMockitoTests
{

	   @Mock
	   TransactionRepository transRepo;
	   
	   @InjectMocks
	   TransactionService transService;
	   @Test
	   @Order(1)
	   public void test_getAllTransaction()
	   {
		   List<AccountTransaction> myaccounts=new ArrayList<AccountTransaction>();
		   myaccounts.add(new AccountTransaction(1,"upi",10000,1));
		   myaccounts.add(new AccountTransaction(2,"deposits",2000,2));
		   
		   when(transRepo.findAll()).thenReturn(myaccounts);
		   
		   assertEquals(2, transService.getAllTransaction().size());
	   }
	   @Test @Order(2)
	   public void test_getTransactionById()
	   {
		   List<AccountTransaction> mytrans=new ArrayList<AccountTransaction>();
		   mytrans.add(new AccountTransaction(1,"personal",1500,1));
		   mytrans.add(new AccountTransaction(2,"loan",20000,2));
		   int transId=1;
		   
		   when(transRepo.findAll()).thenReturn(mytrans);
		   assertEquals(transId,transService.getTransactionById(transId).getAcc_Id());
	   }
	   @Test @Order(3)
	   public void test_addTransaction()
	   {
		   AccountTransaction mytrans=new AccountTransaction(3,"student",5800,3);
		   
		   when(transRepo.save(mytrans)).thenReturn(mytrans);
		   assertEquals(mytrans,transService.addTransaction(mytrans));
	   }

	   @Test @Order(4)
	   public void test_updateTransaction()
	   {
		   AccountTransaction accdetails=new AccountTransaction(3,"student",9000,3);
		   
		   when(transRepo.save(accdetails)).thenReturn(accdetails);
		   assertEquals(accdetails,transService.updateTransaction(accdetails));
	   }
	   
	   @Test @Order(5)
	   public void test_deleteTransaction()
	   {
		   AccountTransaction accdetails=new AccountTransaction(3,"student",9000,3);
		    
		   when(transRepo.save(accdetails)).thenReturn(accdetails);
		   transService.deleteTransaction(accdetails);
		   verify(transRepo,times(1)).delete(accdetails);
		   
	   }
}