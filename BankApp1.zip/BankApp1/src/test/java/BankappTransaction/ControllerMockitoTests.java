package BankappTransaction;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import BankTransactionController.TransactionController;
import BankTransactionModel.AccountTransaction;
import BankTransactionService.TransactionService;
@TestMethodOrder(OrderAnnotation.class)
@SpringBootTest(classes= {ServiceMockitoTests.class})
public class ControllerMockitoTests 
{
	@Mock
	TransactionService transService;
	
	@InjectMocks
	TransactionController transController;
	List<AccountTransaction> mytrans;
	AccountTransaction transaction;
	
	@Test
	@Order(1)
	public void test_getAllTransaction()
	{
		mytrans=new ArrayList<AccountTransaction>();
		mytrans.add(new AccountTransaction(1,"personal",8000,1));
		mytrans.add(new AccountTransaction(2,"loan",20000,2));
		 when(transService.getAllTransaction()).thenReturn(mytrans);
		 ResponseEntity<List<AccountTransaction>> result=transController.getTransaction();
		 
		 assertEquals(HttpStatus.FOUND, result.getStatusCode());
		 assertEquals(2, result.getBody().size());
	}
	
	@Test
	@Order(2)
	public void test_getTransactionById()
	{
		transaction=new AccountTransaction(2,"loan",20000,2);
		int transId=2;
		when(transService.getTransactionById(transId)).thenReturn(transaction);
		ResponseEntity<AccountTransaction> res=transController.getTransactionById(transId);
		
		assertEquals(HttpStatus.FOUND,res.getStatusCode());
		assertEquals(transId,res.getBody().getAcc_Id());
	}
	@Test
	@Order(3)
	public void test_addTransaction()
	{
		transaction=new AccountTransaction(3,"loan",8000,3);
		when(transService.addTransaction(transaction)).thenReturn(transaction);
		ResponseEntity<AccountTransaction> res= transController.addTransaction(transaction);
		assertEquals(HttpStatus.CREATED, res.getStatusCode());
		assertEquals(transaction, res.getBody());
	}
	@Test
	@Order(4)
	public void test_updateTransaction() 
	{
		transaction=new AccountTransaction(3,"loan",8000,3);
		int accountId=3;
		when(transService.getTransactionById(accountId)).thenReturn(transaction);
		when(transService.updateTransaction(transaction)).thenReturn(transaction);
		ResponseEntity<AccountTransaction> res=transController.updateTransaction(accountId, transaction);
		
		assertEquals(HttpStatus.OK, res.getStatusCode());
		assertEquals(3,res.getBody().getAcc_Id());
	}
	@Test
	@Order(5)
	public void test_deletetransaction()
	{
		transaction=new AccountTransaction(3,"loan",8000,3);
		int accountId=3;
		when(transService.getTransactionById(accountId)).thenReturn(transaction);
		ResponseEntity<AccountTransaction> res=transController.deleteTransaction(accountId);
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}
}