package com.rabbit.validationsamples.validation.configs;

/**
 * PLEASE NOTE: Using Spring Boot, there is no need to define a MethodValidationPostProcessor bean, this is already available in context.
 */
// @Slf4j
// @Configuration("validationConfig")
public class ValidationConfig {

	// @Bean
	// public MethodValidationPostProcessor methodValidationPostProcessor() {
	//
	// 	return new MethodValidationPostProcessor();
	// }

}
