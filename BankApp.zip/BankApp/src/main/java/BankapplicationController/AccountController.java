package BankapplicationController;
import java.util.List;
import java.util.NoSuchElementException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import BankapplicationModel.AccountDetails;
import BankapplicationService.AccountService;

@RestController
@RequestMapping
public class AccountController 
{

   @Autowired
   AccountService accountService;
   
   @GetMapping("/getaccounts")
   public ResponseEntity<List<AccountDetails>> getAccounts()
   {
	   try 
	   {
		   List<AccountDetails> accounts=accountService.getAllAccounts();
		   return new ResponseEntity<List<AccountDetails>>(accounts,HttpStatus.FOUND);
	   }
	   catch(Exception e)
	   {
		   return new ResponseEntity<>(HttpStatus.NOT_FOUND);
   }
	 
   }
   
   
   @GetMapping("/getaccounts/{acc_Id}")
   public ResponseEntity<AccountDetails> getAccountById(@PathVariable(value="acc_Id")int acc_Id)
   {
	   try
	   {
	   AccountDetails accdetails=accountService.getAccountById(acc_Id);
	   return new ResponseEntity<AccountDetails>(accdetails,HttpStatus.FOUND);
	   }
	   catch(Exception e)
	   {
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);   
	   }
   }
   
   @PostMapping("/addaccount")
   public ResponseEntity<AccountDetails> addAccount(@RequestBody AccountDetails accountdetails)
   {
	   try
	   {
		  accountdetails=accountService.addAccount(accountdetails);
		  return new ResponseEntity<AccountDetails>(accountdetails,HttpStatus.CREATED);
	   }
	   catch(Exception e)
	   {
		  return new ResponseEntity<>(HttpStatus.CONFLICT);
	   }
	  
   }
   
   @PutMapping("/updateaccount")
   public ResponseEntity<AccountDetails> updateAccount(@PathVariable(value="acc_Id")int acc_Id,@RequestBody AccountDetails accountdetails)
   {
	   try
	   {
	   AccountDetails existingaccount=accountService.getAccountById(acc_Id);
	   
	   existingaccount.setAcc_number(accountdetails.getAcc_number());
	   existingaccount.setAcc_Balance(accountdetails.getAcc_Balance());
	   existingaccount.setAcc_type(accountdetails.getAcc_type());
	   accountService.updateAccount(existingaccount);
	   
	   AccountDetails updated_account=accountService.updateAccount(existingaccount);
	   return new ResponseEntity<AccountDetails>(updated_account,HttpStatus.OK);
	   
	   }
	   catch(Exception e)
	   {
		   return new ResponseEntity<>(HttpStatus.CONFLICT);
	   }
	   
   }
   
   @DeleteMapping(path="/deleteaccounts/{acc_Id}")
   public ResponseEntity<AccountDetails> deleteAccount(@PathVariable(value="acc_Id")int acc_Id)
   {
	AccountDetails accdetails=null;
	try
	{
		accdetails=accountService.getAccountById(acc_Id);
		accountService.deleteAccount(accdetails);
	}
	catch(NoSuchElementException e)
	{
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	return new ResponseEntity<AccountDetails>(accdetails,HttpStatus.OK);
   
}
   }
   