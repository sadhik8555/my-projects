package BankapplicationService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import BankapplicationModel.AccountDetails;
import BankapplicationRepository.AccountRepository;

@Component
@Service
public class AccountService
{
	@Autowired
	AccountRepository accountRepo;
	RestTemplate resttemplate;
	
	public List<AccountDetails> getAllAccounts()
	{
		List<AccountDetails> accounts=accountRepo.findAll();
		return accounts;
	}
	public AccountDetails getAccountById(int acc_Id)
	{
		List<AccountDetails> accounts=accountRepo.findAll();
		AccountDetails accdetails=null;
		for(AccountDetails acc:accounts)
		{
			if(acc.getAcc_Id()==acc_Id)
				accdetails=acc;
		}
		return accdetails;
	}
	public AccountDetails addAccount(AccountDetails accdetails)
	{
		accdetails.setAcc_Id(getMaxId());
		accountRepo.save(accdetails); 
		return accdetails;
	}
	public int getMaxId() //utility method to get max id
	{
		return accountRepo.findAll().size()+1;
	}
	
	public AccountDetails updateAccount(AccountDetails accdetails)
	{
		accountRepo.save(accdetails);
		return accdetails;
	}
	
	public void deleteAccount(AccountDetails accdetails)
	{
		
		accountRepo.delete(accdetails);
	}
	public ResponseDto getAccount(int acc_Id)
	{
		ResponseDto responseDto = new ResponseDto();
		AccountDetails accdetails=accountRepo.findById(acc_Id).get();
		AccountDto accountDto = mapToAccountDetails(accdetails);
		ResponseEntity<TransactionDto> responseEntity = resttemplate
				.getForEntity("https://localhost:8081/getAccounts" + accdetails.getAcc_Id(),TransactionDto.class);
		TransactionDto transactionDto = responseEntity.getBody();
		
		System.out.println(responseEntity.getStatusCodeValue());
		responseDto.setAccdetails(accdetails);
		responseDto.setTransaction(transactionDto);
		
		return responseDto;
		
	}
	private AccountDto mapToAccountDetails(AccountDetails accdetails)
	{
		
		AccountDto accountDto = new AccountDto();
		accountDto.setAcc_Id(accdetails.getAcc_Id());
		accountDto.setAcc_number(accdetails.getAcc_number());
		accountDto.setAcc_Balance(accdetails.getAcc_Balance());
		accountDto.setAcc_type(accdetails.getAcc_type());
		return accountDto;
        }
}

