package BankapplicationService;

import BankapplicationModel.AccountDetails;

public class ResponseDto
{

	private TransactionDto transaction;
	
	private AccountDetails accdetails;

	public TransactionDto getTransaction() {
		return transaction;
	}

	public void setTransaction(TransactionDto transaction) {
		this.transaction = transaction;
	}

	public AccountDetails getAccdetails() {
		return accdetails;
	}

	public void setAccdetails(AccountDetails accdetails) {
		this.accdetails = accdetails;
	}

	public ResponseDto(TransactionDto transaction, AccountDetails accdetails) {
		super();
		this.transaction = transaction;
		this.accdetails = accdetails;
	}

	public ResponseDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}