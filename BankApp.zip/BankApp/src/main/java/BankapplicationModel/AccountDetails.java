package BankapplicationModel;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Acc")
public class AccountDetails 
{
	@Id
	@Column(name="acc_Id")
	private int acc_Id;
	@Column(name="acc_number")
	private long acc_number;
	@Column(name="acc-Balance")
	private int acc_Balance;
	@Column(name="acc_type")
	private String acc_type;

	public int getAcc_Id() {
		return acc_Id;
	}

	public void setAcc_Id(int acc_Id) {
		this.acc_Id = acc_Id;
	}

	public long getAcc_number() {
		return acc_number;
	}

	public void setAcc_number(long acc_number) {
		this.acc_number = acc_number;
	}

	public int getAcc_Balance() {
		return acc_Balance;
	}

	public void setAcc_Balance(int acc_Balance) {
		this.acc_Balance = acc_Balance;
	}

	public String getAcc_type() {
		return acc_type;
	}

	public void setAcc_type(String acc_type) {
		this.acc_type = acc_type;
	}

	public AccountDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AccountDetails(int acc_Id, long acc_number, int acc_Balance, String acc_type) {
		super();
		this.acc_Id = acc_Id;
		this.acc_number = acc_number;
		this.acc_Balance = acc_Balance;
		this.acc_type = acc_type;
	}
	
	

}
