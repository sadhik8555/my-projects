package Bankapplication;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import BankapplicationModel.AccountDetails;
import BankapplicationRepository.AccountRepository;
import BankapplicationService.AccountService;

@TestMethodOrder(OrderAnnotation.class)
@SpringBootTest(classes= {ServiceMockitoTests.class})
public class ServiceMockitoTests 
{
   @Mock
   AccountRepository accountRepo;
   
   @InjectMocks
   AccountService accountService;
   
   @Test
   @Order(1)
   public void test_getAllAccounts()
   {
	   List<AccountDetails> myaccounts=new ArrayList<AccountDetails>();
	   myaccounts.add(new AccountDetails(1,125697489,10000,"personal"));
	   myaccounts.add(new AccountDetails(2,58794123,50000,"loan"));
	   
	   when(accountRepo.findAll()).thenReturn(myaccounts);
	   
	   assertEquals(2, accountService.getAllAccounts().size());
   }
   
   @Test @Order(2)
   public void test_getAccountById()
   {
	   List<AccountDetails> myaccounts=new ArrayList<AccountDetails>();
	   myaccounts.add(new AccountDetails(1,125697489,10000,"personal"));
	   myaccounts.add(new AccountDetails(2,58794123,50000,"loan"));
	   int AccountId=1;
	   
	   when(accountRepo.findAll()).thenReturn(myaccounts);
	   assertEquals(AccountId,accountService.getAccountById(AccountId).getAcc_Id());
   }

   @Test @Order(3)
   public void test_addAccount()
   {
	   AccountDetails accdetails=new AccountDetails(3,45786312,50000,"student");
	   
	   when(accountRepo.save(accdetails)).thenReturn(accdetails);
	   assertEquals(accdetails,accountService.addAccount(accdetails));
   }

   @Test @Order(4)
   public void test_updateAccount()
   {
	   AccountDetails accdetails=new AccountDetails(3,45786312,50000,"student");
	   
	   when(accountRepo.save(accdetails)).thenReturn(accdetails);
	   assertEquals(accdetails,accountService.updateAccount(accdetails));
   }
   
   @Test @Order(5)
   public void test_deleteAccount()
   {
	   AccountDetails accdetails=new AccountDetails(3,45786312,50000,"student");
	    
	   when(accountRepo.save(accdetails)).thenReturn(accdetails);
	   accountService.deleteAccount(accdetails);
	   verify(accountRepo,times(1)).delete(accdetails);
	   
   }
}