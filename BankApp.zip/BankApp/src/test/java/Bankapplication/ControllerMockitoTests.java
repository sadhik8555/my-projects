package Bankapplication;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import BankapplicationController.AccountController;
import BankapplicationModel.AccountDetails;
import BankapplicationService.AccountService;
@TestMethodOrder(OrderAnnotation.class)
@SpringBootTest(classes= {ServiceMockitoTests.class})
public class ControllerMockitoTests
{
	@Mock
	AccountService accountService;
	
	@InjectMocks
	AccountController accountController;
    
	List<AccountDetails> myaccounts;
	AccountDetails accounts;
	
	@Test
	@Order(1)
	public void test_getAllAccounts()
	{
		myaccounts=new ArrayList<AccountDetails>();
		myaccounts.add(new AccountDetails(1,125697489,10000,"personal"));
		myaccounts.add(new AccountDetails(2,58794123,50000,"loan"));
		 when(accountService.getAllAccounts()).thenReturn(myaccounts);
		 ResponseEntity<List<AccountDetails>> result=accountController.getAccounts();
		 
		 assertEquals(HttpStatus.FOUND, result.getStatusCode());
		 assertEquals(2, result.getBody().size());
	}
	
	@Test
	@Order(2)
	public void test_getAccountById()
	{
		accounts=new AccountDetails(2,58794123,50000,"loan");
		int accountId=2;
		when(accountService.getAccountById(accountId)).thenReturn(accounts);
		ResponseEntity<AccountDetails> res=accountController.getAccountById(accountId);
		
		assertEquals(HttpStatus.FOUND,res.getStatusCode());
		assertEquals(accountId,res.getBody().getAcc_Id());
	}
	
	@Test
	@Order(3)
	public void test_addAccount()
	{
		accounts=new AccountDetails(3,58794123,50000,"loan");
		when(accountService.addAccount(accounts)).thenReturn(accounts);
		ResponseEntity<AccountDetails> res= accountController.addAccount(accounts);
		assertEquals(HttpStatus.CREATED, res.getStatusCode());
		assertEquals(accounts, res.getBody());
	}
	@Test
	@Order(4)
	public void test_updateAccount() 
	{
		accounts=new AccountDetails(3,58794123,50000,"loan");
		int accountId=3;
		when(accountService.getAccountById(accountId)).thenReturn(accounts);
		when(accountService.updateAccount(accounts)).thenReturn(accounts);
		ResponseEntity<AccountDetails> res=accountController.updateAccount(accountId, accounts);
		
		assertEquals(HttpStatus.OK, res.getStatusCode());
		assertEquals(3,res.getBody().getAcc_Id());
	}
	@Test
	@Order(5)
	public void test_deleteAccount()
	{
		accounts=new AccountDetails(3,58794123,50000,"loan");
		int accountId=3;
		when(accountService.getAccountById(accountId)).thenReturn(accounts);
		ResponseEntity<AccountDetails> res=accountController.deleteAccount(accountId);
		assertEquals(HttpStatus.OK, res.getStatusCode());
	}
}