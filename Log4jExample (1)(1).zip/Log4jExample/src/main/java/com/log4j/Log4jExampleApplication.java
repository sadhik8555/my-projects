package com.log4j;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Log4jExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(Log4jExampleApplication.class, args);
	}

}
