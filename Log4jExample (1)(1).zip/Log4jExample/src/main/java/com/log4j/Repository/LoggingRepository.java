package com.log4j.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.log4j.entity.LogginEntity;


public interface LoggingRepository extends JpaRepository<LogginEntity,Integer>{

}
