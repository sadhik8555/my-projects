package com.log4j.Controller;


import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class LoggingController {
	
	private static final Logger logger = Logger.getLogger(LoggingController.class);
	
	
	//instance initializer block
//	{
//		BasicConfigurator.configure();
//	}
//	
	
	@GetMapping("/log")
	@ResponseBody
	public String logging() {
		
		logger.debug("loding index page..");
		
		return "logging";
	}

}
