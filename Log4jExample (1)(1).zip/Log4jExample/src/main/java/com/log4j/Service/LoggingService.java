package com.log4j.Service;

public class LoggingService {
	
	

}
